<?php
session_start();

// Ambil data dari URL GET
$nama = $_GET['nama'] ?? 'Tidak Diketahui';
$merk = $_GET['merk'] ?? 'Tidak Diketahui';
$tahun = $_GET['tahun'] ?? 'Tidak Diketahui';
$harga = $_GET['harga'] ?? 0;
$gambar = $_GET['gambar'] ?? 'placeholder.jpg';
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Beli Mobil - <?= htmlspecialchars($nama) ?></title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>

<div class="container my-5">
  <h2 class="mb-4 text-center">Pembelian Mobil</h2>

  <div class="row">
    <!-- Gambar Mobil -->
    <div class="col-md-6">
      <img src="uploads/<?= htmlspecialchars($gambar) ?>" class="img-fluid rounded shadow" alt="<?= htmlspecialchars($nama) ?>">
    </div>

    <!-- Form Pembeli -->
    <div class="col-md-6">
      <h4><?= htmlspecialchars($nama) ?></h4>
      <p><strong>Merk:</strong> <?= htmlspecialchars($merk) ?></p>
      <p><strong>Tahun:</strong> <?= htmlspecialchars($tahun) ?></p>
      <p class="text-success fw-bold">Harga: Rp<?= number_format($harga, 0, ',', '.') ?></p>

      <form action="proses_pembelian.php" method="post">
        <!-- Data mobil disembunyikan (dikirim ke proses_pembelian.php) -->
        <input type="hidden" name="mobil_nama" value="<?= htmlspecialchars($nama) ?>">
        <input type="hidden" name="mobil_merk" value="<?= htmlspecialchars($merk) ?>">
        <input type="hidden" name="mobil_tahun" value="<?= htmlspecialchars($tahun) ?>">
        <input type="hidden" name="mobil_harga" value="<?= htmlspecialchars($harga) ?>">

        <!-- Data Pembeli -->
        <div class="mb-3">
          <label for="nama" class="form-label">Nama Pembeli</label>
          <input type="text" name="nama" id="nama" class="form-control" required>
        </div>

        <div class="mb-3">
          <label for="alamat" class="form-label">Alamat</label>
          <textarea name="alamat" id="alamat" class="form-control" required></textarea>
        </div>

        <div class="mb-3">
          <label for="telepon" class="form-label">Nomor Telepon</label>
          <input type="text" name="telepon" id="telepon" class="form-control" required>
        </div>

        <button type="submit" class="btn btn-primary">Konfirmasi Pembelian</button>
        <a href="index.php" class="btn btn-secondary">Kembali</a>
      </form>
    </div>
  </div>
</div>

</body>
</html>
