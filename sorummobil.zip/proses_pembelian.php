<?php
session_start();

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
  $namaPembeli = $_POST['nama'];
  $alamat = $_POST['alamat'];
  $telepon = $_POST['telepon'];

  $mobilNama = $_POST['mobil_nama'];
  $mobilMerk = $_POST['mobil_merk'];
  $mobilTahun = $_POST['mobil_tahun'];
  $mobilHarga = $_POST['mobil_harga'];

  echo "<div style='margin:50px; font-family:sans-serif'>";
  echo "<h2>Terima kasih, $namaPembeli!</h2>";
  echo "<p>Pesanan Anda untuk mobil <strong>$mobilNama</strong> ($mobilMerk, $mobilTahun) dengan harga <strong>Rp" . number_format($mobilHarga, 0, ',', '.') . "</strong> telah kami terima.</p>";
  echo "<p>Kami akan menghubungi Anda di nomor: <strong>$telepon</strong></p>";
  echo "<a href='index.php'>Kembali ke Beranda</a>";
  echo "</div>";
} else {
  echo "Akses tidak sah.";
}
