<?php
// logout.php - Menghapus session dan keluar dari akun

// Mulai session
session_start();

// Hapus semua session
session_unset();  // Hapus semua variabel session
session_destroy(); // Hancurkan session

// Redirect kembali ke halaman login
header("Location: login.php");
exit;
?>
