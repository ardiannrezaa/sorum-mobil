<?php
// config.php - Menghubungkan ke database MySQL

$host = 'localhost';         // Host database, biasanya localhost
$user = 'root';              // Username MySQL default di XAMPP
$pass = '';                  // Password MySQL (kosong di XAMPP)
$dbname = 'mobilshop';       // Nama database

// Buat koneksi ke MySQL
$conn = mysqli_connect($host, $user, $pass, $dbname);

// Periksa apakah koneksi berhasil
if (!$conn) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
?>
