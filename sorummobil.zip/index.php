<?php
session_start();
?>

<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>MobilShop - Jual Mobil Impian Anda</title>

  <!-- Bootstrap 5 -->
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.5/font/bootstrap-icons.css">

  <style>
    html, body { height: 100%; margin: 0; padding: 0; }
    .wrapper { min-height: 100%; display: flex; flex-direction: column; }
    main { flex: 1; }
    .hero {
      background: linear-gradient(rgba(0,0,0,0.4), rgba(0,0,0,0.5)), url('assets/banner-mobil.jpg') center/cover no-repeat;
      color: white;
      padding: 120px 0;
      text-align: center;
    }
    .hero h1 { font-weight: bold; font-size: 3rem; }
    .card-img-top { height: 200px; object-fit: cover; }
    .card:hover {
      transform: translateY(-5px);
      transition: 0.3s ease-in-out;
      box-shadow: 0 8px 20px rgba(0,0,0,0.2);
    }
    footer { background-color: #343a40; color: white; }
  </style>
</head>
<body>

<div class="wrapper">
  <?php include 'includes/navbar.php'; ?>

  <main>
    <!-- Hero Section -->
    <section class="hero">
      <div class="container">
        <h1>Temukan Mobil Impian Anda</h1>
        <p class="lead">MobilShop menyediakan mobil berkualitas, baru dan bekas, dengan harga terbaik.</p>
        <a href="#mobil" class="btn btn-light btn-lg mt-3">Lihat Daftar Mobil</a>
      </div>
    </section>

    <!-- Daftar Mobil -->
    <section class="container my-5" id="mobil">
      <h2 class="text-center mb-4">Mobil Tersedia</h2>
      <div class="row">

        <?php
        // Data mobil statis dengan gambar
        $mobilList = [
          ["nama" => "Toyota Avanza", "merk" => "Toyota", "tahun" => 2022, "harga" => 245000000, "gambar" => "avanza.jpg"],
          ["nama" => "Honda Brio RS", "merk" => "Honda", "tahun" => 2023, "harga" => 210000000, "gambar" => "brio.jpg"],
          ["nama" => "Suzuki Ertiga", "merk" => "Suzuki", "tahun" => 2021, "harga" => 230000000, "gambar" => "ertiga.jpg"],
          ["nama" => "Mitsubishi Xpander", "merk" => "Mitsubishi", "tahun" => 2022, "harga" => 270000000, "gambar" => "xpander.jpg"],
          ["nama" => "Daihatsu Terios", "merk" => "Daihatsu", "tahun" => 2023, "harga" => 260000000, "gambar" => "terios.jpg"],
          ["nama" => "Hyundai Stargazer", "merk" => "Hyundai", "tahun" => 2023, "harga" => 280000000, "gambar" => "stargazer.jpg"]
        ];

        foreach ($mobilList as $mobil):
        ?>
        <div class="col-md-4 mb-4">
          <div class="card h-100">
            <!-- Gambar Mobil -->
            <img src="uploads/<?= htmlspecialchars($mobil['gambar']) ?>" class="card-img-top" alt="<?= htmlspecialchars($mobil['nama']) ?>">

            <!-- Detail Mobil -->
            <div class="card-body">
              <h5 class="card-title"><?= htmlspecialchars($mobil['nama']) ?></h5>
              <p class="card-text text-muted"><?= htmlspecialchars($mobil['merk']) ?> | Tahun <?= $mobil['tahun'] ?></p>
              <p class="card-text text-success fw-bold">Rp<?= number_format($mobil['harga'], 0, ',', '.') ?></p>
              <a href="beli.php?nama=<?= urlencode($mobil['nama']) ?>&merk=<?= urlencode($mobil['merk']) ?>&tahun=<?= $mobil['tahun'] ?>&harga=<?= $mobil['harga'] ?>&gambar=<?= urlencode($mobil['gambar']) ?>" class="btn btn-outline-primary w-100">Beli Sekarang</a>

            </div>
          </div>
        </div>
        <?php endforeach; ?>

      </div>
    </section>
  </main>

  <footer class="text-center py-3 mt-auto">
    <p class="mb-0">&copy; <?= date('Y') ?> MobilShop. All rights reserved.</p>
  </footer>
</div>

<!-- Bootstrap JS -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
